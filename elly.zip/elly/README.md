# Elly — E-learning (Next.js)

A simple full-stack **Next.js** e-learning starter app created for Kangume Elly.

## Features
- Next.js frontend with Tailwind CSS
- Simple file-based API (JSON files in /data) to manage courses
- Admin page to create courses (writes to data/courses.json)
- Course listing and course detail pages
- No external DB required — easy to get started

## How to run locally
1. Install dependencies:
```bash
npm install
```
2. Run development server:
```bash
npm run dev
```
3. Open http://localhost:3000

## Notes & next steps
- This starter uses JSON files for simplicity. For production switch to a real database (Postgres, MySQL, SQLite).
- Add authentication (NextAuth or custom) before enabling user enrollments.
- Secure API routes (currently unprotected).
- Replace sample user password storage with hashed passwords.

Enjoy — built for Kangume Elly.

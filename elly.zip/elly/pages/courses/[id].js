import {useRouter} from 'next/router'
import useSWR from 'swr'
const fetcher = (url) => fetch(url).then(r=>r.json())

export default function CourseDetail(){
  const router = useRouter()
  const {id} = router.query
  const {data} = useSWR(id ? '/api/courses/'+id : null, fetcher)
  const course = data?.course

  if(!course) return <div className="p-6">Loading…</div>

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-2xl font-bold">{course.title}</h1>
        <p className="text-gray-600">{course.subtitle}</p>
        <p className="mt-4">{course.description}</p>
        <div className="mt-6">
          <h3 className="font-semibold">Lessons</h3>
          <ol className="mt-2 list-decimal list-inside">
            {course.lessons.map((l,idx)=>(
              <li key={idx} className="py-2">
                <div className="font-medium">{l.title}</div>
                <div className="text-sm text-gray-600">{l.duration}</div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  )
}

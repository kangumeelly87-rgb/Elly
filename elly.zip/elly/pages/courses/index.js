import Link from 'next/link'
import useSWR from 'swr'
const fetcher = (url) => fetch(url).then(r=>r.json())

export default function Courses(){
  const {data} = useSWR('/api/courses', fetcher)
  const courses = data?.courses || []

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-5xl mx-auto px-6 py-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold">All courses</h1>
          <nav className="space-x-4">
            <Link href="/"><a className="text-sm">Home</a></Link>
            <Link href="/admin"><a className="text-sm">Admin</a></Link>
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-6">
        <div className="grid md:grid-cols-2 gap-4">
          {courses.map(c=>(
            <div key={c.id} className="bg-white border rounded p-4">
              <h3 className="font-semibold">{c.title}</h3>
              <p className="text-sm text-gray-600">{c.subtitle}</p>
              <div className="mt-3">
                <Link href={'/courses/'+c.id}><a className="text-blue-600">Open course →</a></Link>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}

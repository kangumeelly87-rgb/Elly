import {useState} from 'react'

export default function Admin(){
  const [title, setTitle] = useState('')
  const [subtitle, setSubtitle] = useState('')
  const [message, setMessage] = useState('')

  async function create(){
    const res = await fetch('/api/courses', {
      method: 'POST',
      headers:{'content-type':'application/json'},
      body: JSON.stringify({title, subtitle})
    })
    const j = await res.json()
    if(j.success){
      setMessage('Course created — refresh to see it.')
      setTitle(''); setSubtitle('')
    } else {
      setMessage('Error: '+ (j.error||'unknown'))
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto p-6">
        <h1 className="text-2xl font-bold">Admin — Course management</h1>
        <div className="mt-4 bg-white p-4 rounded shadow">
          <label className="block">Title
            <input value={title} onChange={e=>setTitle(e.target.value)} className="block mt-1 w-full border rounded p-2"/>
          </label>
          <label className="block mt-3">Subtitle
            <input value={subtitle} onChange={e=>setSubtitle(e.target.value)} className="block mt-1 w-full border rounded p-2"/>
          </label>
          <div className="mt-3">
            <button onClick={create} className="px-4 py-2 rounded bg-blue-600 text-white">Create course</button>
          </div>
          {message && <p className="mt-3 text-sm text-green-600">{message}</p>}
        </div>
      </div>
    </div>
  )
}

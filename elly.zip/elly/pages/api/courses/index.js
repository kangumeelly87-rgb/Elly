import fs from 'fs'
import path from 'path'

const dataFile = path.join(process.cwd(), 'data', 'courses.json')

function readData(){
  try{
    return JSON.parse(fs.readFileSync(dataFile,'utf8'))
  }catch(e){
    return {courses:[]}
  }
}

export default function handler(req,res){
  if(req.method === 'GET'){
    const d = readData()
    return res.status(200).json(d)
  }
  if(req.method === 'POST'){
    const {title, subtitle} = req.body
    if(!title) return res.status(400).json({success:false, error:'Title required'})
    const d = readData()
    const id = Date.now().toString()
    const newC = {id, title, subtitle, description: 'This is a new course. Edit the JSON file to add full content.', price: 0, lessons: []}
    d.courses.unshift(newC)
    fs.writeFileSync(dataFile, JSON.stringify(d,null,2))
    return res.status(201).json({success:true, course:newC})
  }
  res.status(405).end()
}

import fs from 'fs'
import path from 'path'

const dataFile = path.join(process.cwd(), 'data', 'courses.json')

function readData(){
  try{
    return JSON.parse(fs.readFileSync(dataFile,'utf8'))
  }catch(e){
    return {courses:[]}
  }
}

export default function handler(req,res){
  const {id} = req.query
  const d = readData()
  const course = d.courses.find(c=>c.id===id)
  if(!course) return res.status(404).json({error:'Not found'})
  return res.status(200).json({course})
}

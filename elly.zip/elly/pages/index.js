import Link from 'next/link'
import useSWR from 'swr'

const fetcher = (url) => fetch(url).then(r=>r.json())

export default function Home(){
  const {data, error} = useSWR('/api/courses', fetcher)
  const courses = data?.courses || []

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-5xl mx-auto px-6 py-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Elly — E‑learning</h1>
          <nav className="space-x-4">
            <Link href="/"><a className="text-sm">Home</a></Link>
            <Link href="/courses"><a className="text-sm">Courses</a></Link>
            <Link href="/admin"><a className="text-sm">Admin</a></Link>
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-6">
        <section className="bg-white rounded-lg p-6 shadow">
          <h2 className="text-xl font-semibold mb-2">Featured courses</h2>
          <p className="text-gray-600 mb-4">Learn at your pace. Sample courses below.</p>

          <div className="grid md:grid-cols-3 gap-4">
            {courses.map(c=>(
              <article key={c.id} className="border rounded p-4 bg-white">
                <h3 className="font-semibold">{c.title}</h3>
                <p className="text-sm text-gray-600">{c.subtitle}</p>
                <p className="mt-2 font-bold">UGX {c.price}</p>
                <Link href={'/courses/'+c.id}><a className="mt-3 inline-block text-blue-600 text-sm">View course →</a></Link>
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="text-center py-6 text-sm text-gray-500">
        © {new Date().getFullYear()} Elly — built for Kangume Elly
      </footer>
    </div>
  )
}
